let btns = document.querySelectorAll(".port")
btns.forEach((btn) => {
    btn.onclick = () => {
        let name = btn.getAttribute("data-name");
        localStorage.setItem("name", name);
        window.location.href = "portofolio.html";
    };
});
