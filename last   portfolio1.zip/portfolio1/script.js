// الحصول على العنصر navbar
var navbar = document.getElementById("navbar");
var links = navbar.querySelectorAll('ul li a');

// إضافة أو إزالة الفئة "scrolled" بناءً على التمرير
window.onscroll = function () {
    var scrollPosition = document.documentElement.scrollTop || document.body.scrollTop;

    // تغيير الفئة بناءً على موضع التمرير
    if (scrollPosition > 50) { // إذا كانت المسافة المقطوعة أكثر من 50 بيكسل
        navbar.classList.add("scrolled");
    } else {
        navbar.classList.remove("scrolled");
    }

    // تغيير لون الرابط النشط بناءً على القسم المرئي
    links.forEach(link => {
        var section = document.querySelector(link.getAttribute('href'));
        var sectionTop = section.offsetTop - navbar.offsetHeight; // موضع القسم مع الأخذ في الاعتبار ارتفاع الناف بار
        var sectionBottom = sectionTop + section.offsetHeight;

        if (scrollPosition >= sectionTop && scrollPosition < sectionBottom) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
};




function toggleMenu() {
    var navLinks = document.getElementById("navLinks");
    if (navLinks.style.display === "block") {
        navLinks.style.display = "none";
    } else {
        navLinks.style.display = "block";
    }
}


window.addEventListener('scroll', function() {
    const contents = document.querySelectorAll('.content');
    const screenPosition = window.innerHeight;

    contents.forEach(content => {
        const contentPosition = content.getBoundingClientRect().top;

        if (contentPosition < screenPosition) {
            content.classList.add('visible');
        }
    });
});


window.addEventListener('wheel', function(event) {
    event.preventDefault(); // منع التمرير الافتراضي

    const sections = document.querySelectorAll('.content');
    let currentSection = Array.from(sections).find(section => {
        const rect = section.getBoundingClientRect();
        return rect.top >= 0 && rect.top < window.innerHeight;
    });

    if (event.deltaY > 0) {
        // إذا كان الاتجاه لأسفل
        const nextSection = currentSection.nextElementSibling;
        if (nextSection) {
            nextSection.scrollIntoView({ behavior: 'smooth' });
        }
    } else {
        // إذا كان الاتجاه لأعلى
        const prevSection = currentSection.previousElementSibling;
        if (prevSection) {
            prevSection.scrollIntoView({ behavior: 'smooth' });
        }
    }
});




document.addEventListener("DOMContentLoaded", () => {
    let header = document.getElementById("header"); 
    let name = localStorage.getItem("name"); 
    
  

    if (name) {
        header.textContent = name;
    } else {
        header.textContent = "No name provided!"; 
    }
});